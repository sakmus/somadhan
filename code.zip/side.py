import wolframalpha

client = wolframalpha.Client("8XGQQX-3YYEX5UPE7")
res = client.query('plot of sinx')

for pod in res.pods:
    if pod.title == 'Plots':
        print(pod.subpod[0].img.alt)
        # print(pod)
